//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 1 question 4

#include <iostream>
using namespace std;
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert>
#include "User.h"


User::User()
{
    username_ = "";
    for(int i = 0; i < size_; i++) //this for loop sets all the elements of likes_  to -1
    {
        likes_[i] = -1; 
    }
    num_posts_ = 0;
}
User::User(string username, int likes[], int num_posts) // num_posts wont exeed the size of the member data
{
    username_ = username;
    for(int i = 0; i < num_posts; i++)
    {
        likes_[i] = likes[i]; 
    }
    for(int i = num_posts; i < size_; i++)
    {
        likes_[i] = -1;
    }
    num_posts_ = num_posts;
}
string User::getUsername()
{
    return username_; 
}
void User::setUsername(string username)
{
    username_ = username; 
}
int User::getLikesAt(int post_id) // index of the post to look for 
{  
    if(post_id >= 0 && post_id < size_)
    {
        return likes_[post_id];
    }
    else
    {
        return -2;
    }
}
bool User::setLikesAt(int post_id, int num_likes)
{  
    if((post_id >= 0 && post_id < num_posts_ ) && (num_likes <= 10 && num_likes >= -1))
    {
        likes_[post_id] = num_likes;
        return true; 
    }
    else
    {
        return false;
    }
    
    
}
int User::getSize()
{
    return size_;
}
void User::setNumPosts(int num_posts)
{
    if(num_posts >=0 && num_posts <= 50)
    {
        num_posts_ = num_posts;
    }
    else
    {
        num_posts_ = num_posts;
    }
}
int User::getNumPosts()
{
    return num_posts_;
}
