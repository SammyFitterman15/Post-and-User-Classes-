//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 1 question 1

#include <iostream>
using namespace std;
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert>
#include "Post.h"

int main()
{
    Post post_1 = Post(); // default constructor
    Post post_2 = Post("new post","Raegan", 10, "10/02/22"); // parameterized constructor
    Post post_3 = Post("empty body","John", 100, "03/29/2004"); // parameterized constructor
    
    assert(post_1.getPostBody() == "");
    assert(post_1.getPostAuthor() == "");
    assert(post_1.getPostLikes() == 0);
    assert(post_1.getPostDate() == "");

    assert(post_2.getPostBody() == "new post");
    assert(post_2.getPostAuthor() == "Raegan");
    assert(post_2.getPostLikes() == 10);
    assert(post_2.getPostDate() == "10/02/22");

    assert(post_3.getPostBody() == "empty body");
    assert(post_3.getPostAuthor() == "John");
    assert(post_3.getPostLikes() == 100);
    assert(post_3.getPostDate() == "03/29/2004");

    post_1.setPostBody("new body");
    post_1.setPostAuthor("new author");
    post_1.setPostLikes(1000);
    post_1.setPostDate("0/0/0");

    post_2.setPostBody("new body");
    post_2.setPostAuthor("new author");
    post_2.setPostLikes(1000);
    post_2.setPostDate("0/0/0");

    post_3.setPostBody("new body");
    post_3.setPostAuthor("new author");
    post_3.setPostLikes(1000);
    post_3.setPostDate("0/0/0");

    cout<<post_1.getPostBody() << endl;
    cout<<post_1.getPostAuthor() << endl;
    cout<<post_1.getPostLikes() << endl;
    cout<<post_1.getPostDate() << endl; 

    cout<<post_2.getPostBody() << endl;
    cout<<post_2.getPostAuthor() << endl;
    cout<<post_2.getPostLikes() << endl;
    cout<<post_2.getPostDate() << endl; 

    cout<<post_3.getPostBody() << endl;
    cout<<post_3.getPostAuthor() << endl;
    cout<<post_3.getPostLikes() << endl;
    cout<<post_3.getPostDate() << endl;
    return 0;
}