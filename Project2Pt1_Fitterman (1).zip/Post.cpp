//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 1 question 1

#include <iostream>
using namespace std;
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert>
#include "Post.h"


Post::Post()
{
    body_ = "";
    post_author_ = "";
    num_likes = 0; 
    date_ = "";
}

Post::Post(string body, string post_author, int likes, string date)
{
    body_ = body;
    post_author_ = post_author;
    num_likes = likes; 
    date_ = date;
}

void Post::setPostBody(string body)
{
    body_ = body;
}
string Post::getPostBody()
{
    return body_;
}

string Post::getPostAuthor()
{
    return post_author_; 
}

void Post::setPostAuthor(string author)
{
    post_author_ = author; 
}
        
int Post::getPostLikes()
{  
    return num_likes; 
}

void Post::setPostLikes(int likes)
{
    if(likes < 0)
    {
        num_likes = likes;
    }
    else
    {
        num_likes = likes; 
    }
}
    

string Post::getPostDate()
{
    return date_;
}

void Post::setPostDate(string date)
{
    date_ = date; 
}






