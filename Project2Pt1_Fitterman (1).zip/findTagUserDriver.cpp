//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 1 question 7

#include <iostream>
using namespace std;
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert>
#include "User.h"

void findTagUser(string username_tag, User users[], int num_users_stored)
{

    int num_users_found = 0; // number of users found will be incremented throughout the program or checked to be zero at the end  
    User user_temp[num_users_stored]; // declared a user temp array to the size of the number of users stored in users
    int tag_length = username_tag.length(); // creates a integer varaible that is equal to the length of the tag to be used in substring interation 


    for(int i = 0; i < num_users_stored; i++) // intereates through the total number of users stored 
    {
        int length = users[i].getUsername().length(); // creates a integer variable that is equal to length of the username at a given index i 
        for(int x = 0; x < length; x++) // interated through the length of the username 
        {
            if(users[i].getUsername().substr(x,tag_length) == username_tag) // gets if the substring x to the length of the tag is equal to the username tag 
            {
                user_temp[num_users_found] = users[i]; // if it is equal to then it sets that username to the index of the number of users found in the user_temp array, to be used to print out list of usernames that contain the username tag 
                num_users_found++; // increments number of users found 
            }
        }
    }
    if(num_users_stored <= 0) // checks if there are not users in the array 
    {
        cout << "No users are stored in the database" << endl; 
        return; 
    }

    if(num_users_found == 0) // checks if no users that contain the tag were in the array 
    {
        cout << "No matching user found" << endl; 
        return;
    }
    if(num_users_found >= 1) // checks if at least one username in the array contained the tag 
    {
        cout << "Here are all the usernames that contain " << username_tag << endl; // prints on a loop all the usernames that contian the tag in the temp array 
        for(int i = 0; i < num_users_found; i++)
        {
            cout << user_temp[i].getUsername() << endl;
        }
    }
}

int main()
{
    User user_array[5];
    int likes1[3] = {1, 0, -1};
    int likes2[3] = {4, 5, 0};
    user_array[0] = User("foliwn22", likes1, 3);
    user_array[1] = User("joh23k", likes2, 3);
    user_array[2] = User("harry02", likes2, 3);
    user_array[3] = User("luwkml1", likes2, 3);
    user_array[4] = User("fwollow3", likes1, 3);
    findTagUser("wkm", user_array, 5);
}
