//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 1 question 6

#include <iostream>
using namespace std;
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert>
#include "User.h"
#include "Post.h"

int getLikes(string post_author, Post posts[], int num_posts_stored, string username, User users[], int num_users_stored)
{
    if(num_posts_stored <= 0 || num_users_stored <=0) // checks to make sure there are at least 1 post and at least 1 user in each array 
    {
        return -2;
    }
    int post_index = -1; // used to find index of post
    int user_index = -1; // used to find index of post
    bool user = false; // used to check if the user exist or not
    bool post = false; // used to check if the post exist or not 
    for(int i = 0; i < num_posts_stored; i++) // find the post index and sets post to true if it exist 
    {
        if(posts[i].getPostAuthor() == post_author)
        {
            post_index = i; 
            post = true;
            break;
        }

    }
    for(int i = 0; i < num_users_stored; i++) //finds the user index and sets user to true if it exist 
    {
        if(users[i].getUsername() == username)
        {
            user_index = i; 
            user = true;
            break;
        }

    }
    if(!post || !user) // checks to see if post or user dont exist and return -3 if either or both dont exist 
    {
        return -3;
    }

    return users[user_index].getLikesAt(post_index);
}



int main()
{


    Post posts[3]; 
    Post my_post_1 = Post("Hello!","Xuefei", 10, "10/02/22");
    posts[0] = my_post_1;
    Post my_post_2 = Post("new post","Morgan", 9, "10/04/22");
    posts[1] = my_post_2;
    Post my_post_3 = Post("Hey!","Jot", 10, "10/05/22");
    posts[2] = my_post_3;


    User users[2];
    // user 1
    int likes1[3] = {1, 3, 2};
    User u1 = User("bookworm43", likes1, 3);
    users[0] = u1; // insert first object at index 0
    // user 2
    users[1].setUsername("roboticscu");
    users[1].setLikesAt(0,-1); 
    users[1].setLikesAt(1,2); 
    users[1].setLikesAt(2,4);

    int x = getLikes("Xuefei", posts, 3, "bookworm43", users, 2);

    cout << x << endl;
    
}







    