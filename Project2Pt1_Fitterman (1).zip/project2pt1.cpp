//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 1 question 8

#include <iostream>
using namespace std;
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert>
#include "User.h"
#include "Post.h"
/*
  Breakdown of Post class:
    - The post class contains 4 member data variables:
        - a string for the body of the post, 
        - a string for the post author, 
        - an integer for the number of likes, 
        - a string for the date of the post 
    - The post class has a parameterized and default constructor 
    - There are 8 member functions 
        - void setPostBody(string body)
        - string getPostBody()
        - string getPostAuthor()
        - void setPostAuthor(string author)
        - int getPostLikes()
        - void setPostLikes(int likes)
        - string getPostDate()
        - void setPostDate(string date)
  Breakdown of User class:
    - The User class contains 3 mutable member data variable and one static constant integer 
        - string username_;
        - int num_posts_;
        - static const int size_ = 50; 
        - int likes_[size_];

*/

int split(string input_string, char seperator, string array[], int array_size) 
{
    string words = ""; 
    int array_index = 0;
    int count = 0; 
    int i; 
    if(input_string.length() < 1)
    {
        return 0; 
    }
    for(i = 0; i < input_string.length(); i++)
    {
        if(input_string[i] == seperator)
        {
            count++;
            if(words.length() > 0)
            {
                array[array_index] = words;
                array_index++; 
                words = "";
            }
            words = "";
        }
        else
        {
            words += input_string[i];
        }
        if(i == input_string.length() - 1)
        {
            if(words.length() > 0)
            {
                array[array_index] = words;
                array_index++; 
                words = "";
            }
        }
    }
    if(count == 0)
    {
        return 1;
    }
    if(count >= array_size)
    {
        return -1; 
    }
    return count+1; 
}
int readPosts(string file_name, Post posts[], int num_posts_stored, int posts_arr_size)
{
    ifstream file_input; 
    file_input.open(file_name); // opens file
    if(num_posts_stored == posts_arr_size) // makes sure the array is not already full and returns -2 if it is 
    {
        return -2;
    }
    if(file_input.fail() && num_posts_stored == posts_arr_size) // makes sure the file opens and that the array is not already full and return -2 if it is 
    {
        return -2; 
    }
    if (file_input.fail()) // makes sure just the file does not fail to open  and returns -1 if it is 
    {
        return -1; 
    }
    else
    {
        string line = "";
        string arr[5];
        while(!file_input.eof() && num_posts_stored < posts_arr_size) // loops through while there is still data in the file and the number of posts stored does not exceed the array size
        {
            getline(file_input, line); // gets a line to read 
            
            int x = split(line,',',arr,5);  // calls helper function split that interated through a string and splits into an array based on a delimeter and returns the numbers of splits
            if(x == 4) // if split returns 4 meaning there were four parts of the string between the delimeter 
            {
                string text = arr[0]; //gets post body 
                string name = arr[1]; //gets person who wrote posts 
                int likes = stoi(arr[2]); // gets number of likes, this is converted to an integer from  a string 
                string date = arr[3]; // gets the date of the posts 
                Post post = Post(text, name, likes, date); // creates a posts object for the given parameters from the array created by split 
                posts[num_posts_stored] = post; //stores the post object in an array of posts objects at the index of the number of posts stored
                num_posts_stored++; // increments the number of posts stored 
            }
        }
        file_input.close(); // closes file
        return num_posts_stored; // 
    }
}
int readLikes(string file_name, User users[], int num_users_stored, int users_arr_size, int max_posts)
{
   
    if(num_users_stored == users_arr_size) //makes sure that the users array is not already full and returns -2 if it is 
    {
        return -2;
    }
    ifstream file_input; 
    file_input.open(file_name); // opens file 
    if(file_input.fail() && num_users_stored == users_arr_size) // makes sure the file does not fail to open and the users array is not already full and return -2 if it is
    {
        return -2; 
    }
    if (file_input.fail()) //makes sure the file does not fail to open and returns -1 if it does fail to open 
    {
        return -1; 
    }
    else
    {
        int size_arr = max_posts +1; //parameter for split 
        string line = ""; // parameter for split 
        string arr[size_arr]; // creates an array to pass into split 
        int likes[max_posts]; // initializes likes array to the max number of posts stored 
        while(!file_input.eof() && num_users_stored < users_arr_size) // loops while there is still more data to be read in the file and the number of users stored does not exceed the size of the array 
        {
            getline(file_input, line); // gets line 
            int x = split(line,',',arr,size_arr); // calls helper function split that interated through a string and splits into an array based on a delimeter and returns the numbers of splits
            if(line.length() != 0 && x == size_arr)
            {
                string name = arr[0]; // sets the zero index of the array populated by split to the name of the users
                for(int i = 0; i < max_posts; i++) // interates through the maximum amount of posts 
                {
                    likes[i] = stoi(arr[i+1]); // sets the index of i in likes to the index of i+1 of the array populated by the split function 
                }
                User user = User(name, likes, max_posts); // creates a user object from the line passed into split, uses three parameters 
                users[num_users_stored] = user; // sets the user object to the number of users stored index in the users array
                num_users_stored++; // increments number of users stored 
            }
        }
        file_input.close(); // closes file 
        return num_users_stored; 
    }
}
void findTagUser(string username_tag, User users[], int num_users_stored)
{

    int num_users_found = 0; // number of users found will be incremented throughout the program or checked to be zero at the end  
    User user_temp[num_users_stored]; // declared a user temp array to the size of the number of users stored in users
    int tag_length = username_tag.length(); // creates a integer varaible that is equal to the length of the tag to be used in substring interation 


    for(int i = 0; i < num_users_stored; i++) // intereates through the total number of users stored 
    {
        int length = users[i].getUsername().length(); // creates a integer variable that is equal to length of the username at a given index i 
        for(int x = 0; x < length; x++) // interated through the length of the username 
        {
            if(users[i].getUsername().substr(x,tag_length) == username_tag) // gets if the substring x to the length of the tag is equal to the username tag 
            {
                user_temp[num_users_found] = users[i]; // if it is equal to then it sets that username to the index of the number of users found in the user_temp array, to be used to print out list of usernames that contain the username tag 
                num_users_found++; // increments number of users found 
            }
        }
    }
    if(num_users_stored <= 0) // checks if there are not users in the array 
    {
        cout << "No users are stored in the database" << endl; 
        return; 
    }

    if(num_users_found == 0) // checks if no users that contain the tag were in the array 
    {
        cout << "No matching user found" << endl; 
        return;
    }
    if(num_users_found >= 1) // checks if at least one username in the array contained the tag 
    {
        cout << "Here are all the usernames that contain " << username_tag << endl; // prints on a loop all the usernames that contian the tag in the temp array 
        for(int i = 0; i < num_users_found; i++)
        {
            cout << user_temp[i].getUsername() << endl;
        }
    }
}

int getLikes(string post_author, Post posts[], int num_posts_stored, string username, User users[], int num_users_stored)
{
    if(num_posts_stored <= 0 || num_users_stored <=0) // checks to make sure there are at least 1 post and at least 1 user in each array 
    {
        return -2;
    }
    int post_index = -1; // used to find index of post
    int user_index = -1; // used to find index of post
    bool user = false; // used to check if the user exist or not
    bool post = false; // used to check if the post exist or not 
    for(int i = 0; i < num_posts_stored; i++) // find the post index and sets post to true if it exist 
    {
        if(posts[i].getPostAuthor() == post_author)
        {
            post_index = i; 
            post = true;
        }

    }
    for(int i = 0; i < num_users_stored; i++) //finds the user index and sets user to true if it exist 
    {
        if(users[i].getUsername() == username)
        {
            user_index = i; 
            user = true;
        }
    }
    if(!post || !user) // checks to see if post or user dont exist and return -3 if either or both dont exist 
    {
        return -3;
    }
    for(int i = 0; i < num_posts_stored; i++ ) // finds the likes to return 
    {
        if(posts[i].getPostAuthor() == post_author) // checks if the post author at index i in posts[] is the post author were looking for 
        {
            if(users[user_index].getLikesAt(i) == -1) // if the likes is eqaul to -1 means the user has not liked it and there are actually zero likes 
            {
                return 0;
            }
            else // otherwise returns the actaul value of the likes 
            {
                return users[user_index].getLikesAt(i);
            }
        }
    }
    return -1; 
}

void printPostsByYear(Post posts[], string year, int num_post_stored)
{
    int count; 
    string arr[num_post_stored]; //
    if(num_post_stored <= 0) // checks to make sure there is at least one post in the array 
    {
        cout << "No posts are stored" << endl;
    }
    for(int i = 0; i < num_post_stored; i++) // iterates through all the posts stored 
    {
        string date_ = posts[i].getPostDate(); //gets the date of the post at the given index i 
        string year_ = date_.substr(6,7); // sets the year_ to the last two idexes of date
        if(year_ == year) //  checks if their equivalent 
        {
            arr[count] = posts[i].getPostBody(); // sets the index of the current counter in array arr to the body of the post at given index i that matched years with given year in parameter 
            count++;
        }
    }
    if(count == 0) // checks if no years matched 
    {
        cout << "No posts stored for year " << year << endl; 
    }

    if(count > 1) // checks if at least one post matched the year parameter 
    {
        cout << "Here is a list of posts for year " << year << endl; 
        for(int i = 0; i < count; i++) // iterates through the amount of post counted with correct year and prints them out 
        {
            cout << arr[i] << endl;
        }
    }
}
int main() // make sure to update getLikes functions!
{
    string choice = "0"; 
    int num_posts_stored = 0;
    int num_users_stored = 0;
    Post posts[50];
    User users[50];
    while(stoi(choice) != 6)
    {
        cout << "======Main Menu======" << endl << "1. Read Posts" << endl << "2. Print Posts By Year" << endl << "3. Read Likes" << endl << "4. Get Likes" << endl << "5. Find users with matching tag" << endl << "6. Quit" << endl;
        getline(cin,choice);
        int new_choice = stoi(choice);
        switch(new_choice)
        {
            case 1:
                {
                string file_name_1 = "";
                cout << "Enter a post file name:" << endl;
                getline(cin,file_name_1);
                int x = readPosts(file_name_1, posts, num_posts_stored, 50);
                if(x == -1)
                {
                    cout << "File failed to open. No posts saved to the database." << endl;
                }
                else if(x == -2)
                {
                    cout << "Database is already full. No posts were added." << endl;
                }
                else if(x == 50)
                {
                    num_posts_stored = x;
                    cout << "Database is full. Some posts may have not been added." << endl;
                }
                else if(x >= 0 && x < 50)
                {
                    num_posts_stored = x;
                    cout << "Total posts in the database: " << x << endl;
                }
                break;
                }   
            case 2:
                {
                string date = ""; 
                cout << "Enter the year(YY):" << endl;
                getline(cin,date);
                printPostsByYear(posts, date, num_posts_stored);
                break;
                }
            case 3:
                {
                string file_name_2 = "";
                cout << "Enter a user file name:" << endl;
                getline(cin,file_name_2);
                num_users_stored = readLikes(file_name_2, users, num_users_stored, 50, 50);
                cout << y << endl;
                if(num_users_stored == -1)
                {
                    cout << "File failed to open. No users saved to the database." << endl;
                }
                else if(num_users_stored == -2)
                {
                    cout << "Database is already full. No users were added." << endl;
                }
                else if(num_users_stored == 50)
                {
                    num_users_stored = y;
                    cout << "Database is full. Some users may have not been added." << endl;
                }
                else if(num_users_stored >= 0 && num_users_stored < 50)
                {
                    num_users_stored = y;
                    cout << "Total users in the database: " << num_users_stored << endl;
                }
                break;
                }
            case 4:
                {
                string post_author = ""; 
                cout << "Enter a post author:" << endl;
                getline(cin,post_author);
                string username = ""; 
                cout << "Enter a user name:" << endl;
                getline(cin,username);
                int z = getLikes(post_author,posts, num_posts_stored, username, users, num_users_stored);
                if(z == 0)
                {
                    cout << username << " has not liked the post posted by " << post_author << endl;
                }
                else if(z == -1)
                {
                    cout << username << " has not viewed the post posted by " << post_author << endl;
                }
                else if(z == -2)
                {
                    cout << "Database is empty." << endl;
                }
                else if(z == -3)
                {
                    cout << username << " or " << post_author << " does not exist." << endl;
                }
                else
                {
                    cout << username << " liked the post posted by " << post_author << " " << z << " times" << endl;
                }
                break;
                }
            case 5:
                {
                string user_tag = "";
                cout << "Enter a tag:" << endl;
                getline(cin,user_tag);
                findTagUser(user_tag, users, num_users_stored);
                break;
                }
            case 6:
                {
                cout << "Good bye!" << endl;
                break;
                }
            default:
            {
                cout << "Invalid input." << endl;
            }
           
        }
    }
    return 0;
}




// To do for Project 2 part one

// - Make sure all programs run and there are test cases for each driver file 
// - Fix get likes and write comments
// - Get main functions running for project2pt1.cpp 




/*
int main() // make sure to update getLikes functions!
{
    int choice = 0; 
    int size_ = 50;
    while(choice != 6)
    {
        cout << "======Main Menu======" << endl << "1. Read Posts" << endl << "2. Print Posts By Year" << endl << "3. Read Likes" << endl << "4. Get Likes" << endl << "5. Find users with matching tag" << endl << "6. Quit" << endl;
        cin >> choice; 
        if(choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5 && choice != 6)
        {
            cout << "Invalid input." << endl;
        }
        switch(choice)
        {
            case 1:
                {
                string file_name_1;
                cout << "Enter a post file name:" << endl;
                cin >> file_name_1;
                Post posts_1[size_];
                int num_posts_stored_1 = 0;
                int x = readPosts(file_name_1, posts_1, num_posts_stored_1, size_);
                if(x == -1)
                {
                    cout << "File failed to open. No posts saved to the database." << endl;
                }
                if(x == -2)
                {
                    cout << "Database is already full. No posts were added." << endl;
                }
                if(x == size_)
                {
                    cout << "Database is full. Some posts may have not been added." << endl;
                }
                if(x > 0 && x < size_)
                {
                    cout << "Total posts in the database: " << x << endl;
                }
                break;
                }   
            case 2:
                {
                string date; 
                cout << "Enter the year(YY):" << endl;
                cin >> date;
                Post posts_2[size_];
                int num_posts_stored_2 = 0;
                readPosts("posts.txt", posts_2, num_posts_stored_2, 50);
                printPostsByYear(posts_2, date, num_posts_stored_2);
                break;
                }
            case 3:
                {
                string file_name_2;
                cout << "Enter a user file name:" << endl;
                cin >> file_name_2;
                User users_1[size_];
                int num_users_stored_1 = 0;
                int max_posts_1 = 50;
                int y = readLikes(file_name_2, users_1, num_users_stored_1, size_, max_posts_1);
                if(y == -1)
                {
                    cout << "File failed to open. No users saved to the database." << endl;
                }
                if(y == -2)
                {
                    cout << "Database is already full. No users were added." << endl;
                }
                if(y == size_)
                {
                    cout << "Database is full. Some users may have not been added." << endl;
                }
                if(y > 0 && y < size_)
                {
                    cout << "Total users in the database: " << y << endl;
                }
                break;
                }
            case 4:
                {
                string post_author; 
                cout << "Enter a post author:" << endl;
                cin >> post_author;
                string username; 
                cout << "Enter a user name:" << endl;
                cin >> username;
                Post posts_3[size_];
                int num_posts_stored_3 = 0;
                readPosts("posts.txt", posts_3, num_posts_stored_3, size_);
                User users_2[size_];
                int num_users_stored_2 = 0;
                int max_posts_2 = 50;
                readLikes("users.txt", users_2, num_users_stored_2, size_ ,max_posts_2);
                int z = getLikes(post_author,posts_3, num_posts_stored_3, username, users_2, num_users_stored_2);

                if(z == 0)
                {
                    cout << username << " has not liked the post posted by " << post_author << endl;
                }
                if(z == -1)
                {
                    cout << username << " has not viewed the post posted by " << post_author << endl;
                }
                if(z == -2)
                {
                    cout << "Database is empty." << endl;
                }
                if(z == -3)
                {
                    cout << username << " or " << post_author << " does not exist." << endl;
                }
                break;
                }
            case 5:
                {

                User users[50];
                int num_users_stored_3 = 0;
                int max_posts_3 = 50;
                readLikes("users.txt", users, num_users_stored_3, size_, max_posts_3);
                string user_tag;
                cout << "Enter a tag:" << endl;
                cin >> user_tag;
                findTagUser(user_tag, users, num_users_stored_3);
                break;
                }
            case 6:
                {
                cout << "Good bye!" << endl;
                break;
                }
        }
    }
    return 0;
}
*/


