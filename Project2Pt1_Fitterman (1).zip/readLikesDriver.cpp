//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 1 question 5

#include <iostream>
using namespace std;
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert>
#include "User.h"
int split(string input_string, char seperator, string array[], int array_size) // helper function 
{
    string words = ""; 
    int array_index = 0;
    int count = 0; 
    int i; 
    if(input_string.length() < 1)
    {
        return 0; 
    }
    for(i = 0; i < input_string.length(); i++)
    {
        if(input_string[i] == seperator)
        {
            count++;
            if(words.length() > 0)
            {
                array[array_index] = words;
                array_index++; 
                words = "";
            }
            words = "";
        }
        else
        {
            words += input_string[i];
        }
        if(i == input_string.length() - 1)
        {
            if(words.length() > 0)
            {
                array[array_index] = words;
                array_index++; 
                words = "";
            }
        }
    }
    if(count == 0)
    {
        return 1;
    }
    if(count >= array_size)
    {
        return -1; 
    }
    return count+1; 
}
int readLikes(string file_name, User users[], int num_users_stored, int users_arr_size, int max_posts)
{
   
    if(num_users_stored == users_arr_size) //makes sure that the users array is not already full and returns -2 if it is 
    {
        return -2;
    }
    ifstream file_input; 
    file_input.open(file_name); // opens file 
    if(file_input.fail() && num_users_stored == users_arr_size) // makes sure the file does not fail to open and the users array is not already full and return -2 if it is
    {
        return -2; 
    }
    if (file_input.fail()) //makes sure the file does not fail to open and returns -1 if it does fail to open 
    {
        return -1; 
    }
    else
    {
        int size_arr = max_posts +1; //parameter for split 
        string line = ""; // parameter for split 
        string arr[size_arr]; // creates an array to pass into split 
        int likes[max_posts]; // initializes likes array to the max number of posts stored 
        while(!file_input.eof() && num_users_stored < users_arr_size) // loops while there is still more data to be read in the file and the number of users stored does not exceed the size of the array 
        {
            getline(file_input, line); // gets line 
            int x = split(line,',',arr,size_arr); // calls helper function split that interated through a string and splits into an array based on a delimeter and returns the numbers of splits
            if(line.length() != 0 && x == size_arr)
            {
                string name = arr[0]; // sets the zero index of the array populated by split to the name of the users
                for(int i = 0; i < max_posts; i++) // interates through the maximum amount of posts 
                {
                    likes[i] = stoi(arr[i+1]); // sets the index of i in likes to the index of i+1 of the array populated by the split function 
                }
                User user = User(name, likes, max_posts); // creates a user object from the line passed into split, uses three parameters 
                users[num_users_stored] = user; // sets the user object to the number of users stored index in the users array
                num_users_stored++; // increments number of users stored 
            }
        }
        file_input.close(); // closes file 
        return num_users_stored; 
    }
}

int main()
{

    User users[10]; 
    int num_users_stored = 0; 
    int users_arr_size = 10; 
    int max_posts = 3;
    string file_name = "user.txt";
    assert(readLikes(file_name, users, num_users_stored, users_arr_size, max_posts) == 3); // this is failing 
    return 0;
}

