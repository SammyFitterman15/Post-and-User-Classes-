//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 1 question 4

#include <iostream>
using namespace std;
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert>
#include "User.h"

int main()
{
    
    int testLikes[] = {7,1,8,-1,10,5,5,5,-1,8};
   
    User user_1 = User(); // default constructor
    User user_2 = User("roboticscu", testLikes, 10);
    
    
    assert(user_1.getUsername() == "");
    assert(user_1.getLikesAt(0) == -1);
    assert(user_1.setLikesAt(0,-1) == false);
    assert(user_1.getSize() == 50);
    assert(user_1.getNumPosts() == 0);

    assert(user_2.getUsername() == "roboticscu");
    assert(user_2.getLikesAt(0) == 7);
    assert(user_2.setLikesAt(0,6) == true);
    assert(user_2.getSize() == 50);
    assert(user_2.getNumPosts() == 10);

   
    user_1.setUsername("new username");
    user_1.setNumPosts(5);
    
    user_2.setUsername("new username");
    user_2.setNumPosts(9);

    cout<<user_1.getUsername() << endl;
    cout<<user_1.getNumPosts() << endl;

    cout<<user_2.getUsername() << endl;
    cout<<user_2.getNumPosts() << endl;
    

    return 0;
}