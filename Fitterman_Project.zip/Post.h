//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 1 question 1

#ifndef POST_H
#define POST_H
#include <iostream>
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert> 
using namespace std;

class Post
{
    private: 
        string body_;
        string post_author_; 
        int num_likes;
        string date_;
    public: 
        Post();
        Post(string body_, string post_author_, int num_likes, string date_);
        void setPostBody(string body); 
        string getPostBody();
        string getPostAuthor();
        void setPostAuthor(string author); 
        int getPostLikes();
        void setPostLikes(int likes);
        string getPostDate();
        void setPostDate(string date); 
};


#endif





