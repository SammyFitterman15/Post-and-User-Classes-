//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 1 question 2

#include <iostream>
using namespace std;
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert>
#include "Post.h"

int split(string input_string, char seperator, string array[], int array_size) // helper function 
{
    string words = ""; 
    int array_index = 0;
    int count = 0; 
    int i; 
    if(input_string.length() < 1)
    {
        return 0; 
    }
    for(i = 0; i < input_string.length(); i++)
    {
        if(input_string[i] == seperator)
        {
            count++;
            if(words.length() > 0)
            {
                array[array_index] = words;
                array_index++; 
                words = "";
            }
            words = "";
        }
        else
        {
            words += input_string[i];
        }
        if(i == input_string.length() - 1)
        {
            if(words.length() > 0)
            {
                array[array_index] = words;
                array_index++; 
                words = "";
            }
        }
    }
    if(count == 0)
    {
        return 1;
    }
    if(count >= array_size)
    {
        return -1; 
    }
    return count+1; 
}
int readPosts(string file_name, Post posts[], int num_posts_stored, int posts_arr_size)
{
    ifstream file_input; 
    file_input.open(file_name); // opens file
    if(num_posts_stored == posts_arr_size) // makes sure the array is not already full and returns -2 if it is 
    {
        return -2;
    }
    if(file_input.fail() && num_posts_stored == posts_arr_size) // makes sure the file opens and that the array is not already full and return -2 if it is 
    {
        return -2; 
    }
    // if (file_input.fail()) // makes sure just the file does not fail to open  and returns -1 if it is 
    // {
    //     return -1; 
    // }
    else
    {
        string line = "";
        string arr[5];
        while(!file_input.eof() && num_posts_stored < posts_arr_size) // loops through while there is still data in the file and the number of posts stored does not exceed the array size
        {
            getline(file_input, line); // gets a line to read 
            
            int x = split(line,',',arr,5);  // calls helper function split that interated through a string and splits into an array based on a delimeter and returns the numbers of splits
            if(x == 4) // if split returns 4 meaning there were four parts of the string between the delimeter 
            {
                string text = arr[0]; //gets post body 
                string name = arr[1]; //gets person who wrote posts 
                int likes = stoi(arr[2]); // gets number of likes, this is converted to an integer from  a string 
                string date = arr[3]; // gets the date of the posts 
                Post post = Post(text, name, likes, date); // creates a posts object for the given parameters from the array created by split 
                posts[num_posts_stored] = post; //stores the post object in an array of posts objects at the index of the number of posts stored
                num_posts_stored++; // increments the number of posts stored 
            }
        }
        file_input.close(); // closes file
        return num_posts_stored; // 
    }
}
int main() 
{
    Post post[10];
    int num = readPosts("posts.txt", post, 0, 10); 
    
    assert(post[0].getPostBody() == "Sko buffs!!");
    assert(post[0].getPostAuthor() == "michelleryan");
    assert(post[0].getPostLikes() == 146);
    assert(post[0].getPostDate() == "09/10/20");

    assert(post[1].getPostBody() == "Imagine not having views like this on the way to class!");
    assert(post[1].getPostAuthor() == "cuboulder");
    assert(post[1].getPostLikes() == 241);
    assert(post[1].getPostDate() == "09/11/20");

    assert(post[2].getPostBody() == "Never a dull moment at CU!");
    assert(post[2].getPostAuthor() == "kate128");
    assert(post[2].getPostLikes() == 192);
    assert(post[2].getPostDate() == "08/04/21");

    assert(readPosts("posts.txt",post,0,10) == 3);

}





