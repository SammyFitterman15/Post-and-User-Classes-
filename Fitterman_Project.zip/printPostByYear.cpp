//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 1 question 3

#include <iostream>
using namespace std;
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert>
#include "Post.h"

void printPostsByYear(Post posts[], string year, int num_post_stored)
{
    int count = 0; 
    string arr[num_post_stored]; //
    if(num_post_stored < 0) // checks to make sure there is at least one post in the array 
    {
        cout << "No posts are stored" << endl;
    }
    for(int i = 0; i < num_post_stored; i++) // iterates through all the posts stored 
    {
        string date_ = posts[i].getPostDate(); //gets the date of the post at the given index i 
        string year_ = date_.substr(6,7); // sets the year_ to the last two idexes of date
        if(year_ == year) //  checks if their equivalent 
        {
            arr[count] = posts[i].getPostBody(); // sets the index of the current counter in array arr to the body of the post at given index i that matched years with given year in parameter 
            count++;
        }
    }
    if(count == 0) // checks if no years matched 
    {
        cout << "No posts stored for year " << year << endl; 
    }

    if(count >= 1) // checks if at least one post matched the year parameter 
    {
        cout << "Here is a list of posts for year " << year << endl; 
        for(int i = 0; i < count; i++) // iterates through the amount of post counted with correct year and prints them out 
        {
            cout << arr[i] << endl;
        }
    }
}


int main()
{

    Post p_1 = Post("new post1","Lisa1", 10, "10/02/22");
    Post p_2 = Post("new post2","Lisa2", 11, "10/02/22");
    Post p_3 = Post("new post3","Lisa3", 8, "10/02/19");
        
    Post list_of_posts[] = {p_1, p_2, p_3};
    int number_of_posts = 3;
    string year = "22";
    printPostsByYear(list_of_posts, year, number_of_posts);

    return 0;
}