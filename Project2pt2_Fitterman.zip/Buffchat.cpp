//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 2 

#include <iostream>
using namespace std;
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert> 
#include "Buffchat.h"
#include "User.h"
#include "Post.h"


int split(string input_string, char seperator, string array[], int array_size) 
{
    string words = ""; 
    int array_index = 0;
    int count = 0; 
    int i; 
    if(input_string.length() < 1)
    {
        return 0; 
    }
    for(i = 0; i < input_string.length(); i++)
    {
        if(input_string[i] == seperator)
        {
            count++;
            if(words.length() > 0)
            {
                array[array_index] = words;
                array_index++; 
                words = "";
            }
            words = "";
        }
        else
        {
            words += input_string[i];
        }
        if(i == input_string.length() - 1)
        {
            if(words.length() > 0)
            {
                array[array_index] = words;
                array_index++; 
                words = "";
            }
        }
    }
    if(count == 0)
    {
        return 1;
    }
    if(count >= array_size)
    {
        return -1; 
    }
    return count+1; 
}

Buffchat::Buffchat()
{
    num_posts_ = 0;
    num_users_ = 0;
}
int Buffchat::getPostSize()
{
    return posts_size_;
}
int Buffchat::getUserSize()
{
    return users_size_;
}
int Buffchat::getNumPosts()
{
    return num_posts_;
}
int Buffchat::getNumUsers()
{
    return num_users_;
}
int Buffchat::readPosts(string file_name)
{
    ifstream file_input; 
    file_input.open(file_name); // opens file
    if(num_posts_ == posts_size_) // makes sure the array is not already full and returns -2 if it is 
    {
        return -2;
    }
    if(file_input.fail() && num_posts_ == posts_size_) // makes sure the file opens and that the array is not already full and return -2 if it is 
    {
        return -2; 
    }
    if (file_input.fail()) // makes sure just the file does not fail to open  and returns -1 if it is 
    {
        return -1; 
    }
    else
    {
        string line = "";
        string arr[5];
        while(!file_input.eof() && num_posts_ < posts_size_) // loops through while there is still data in the file and the number of posts stored does not exceed the array size
        {
            getline(file_input, line); // gets a line to read 
            
            int x = split(line,',',arr,5);  // calls helper function split that interated through a string and splits into an array based on a delimeter and returns the numbers of splits
            if(x == 4) // if split returns 4 meaning there were four parts of the string between the delimeter 
            {
                string text = arr[0]; //gets post body 
                string name = arr[1]; //gets person who wrote posts 
                int likes = stoi(arr[2]); // gets number of likes, this is converted to an integer from  a string 
                string date = arr[3]; // gets the date of the posts 
                Post post = Post(text, name, likes, date); // creates a posts object for the given parameters from the array created by split 
                posts_[num_posts_] = post; //stores the post object in an array of posts objects at the index of the number of posts stored
                num_posts_++; // increments the number of posts stored 
            }
        }
        file_input.close(); // closes file
        return num_posts_; 
    }
}
void Buffchat::printPostsByYear(string year)
{
    int count = 0; 
    string arr[num_posts_]; 
    if(num_posts_ <= 0) // checks to make sure there is at least one post in the array 
    {
        cout << "No posts are stored" << endl;
        return;
    }
    for(int i = 0; i < num_posts_; i++) // iterates through all the posts stored 
    {
        string date_ = posts_[i].getPostDate(); //gets the date of the post at the given index i 
        string year_ = date_.substr(6,7); // sets the year_ to the last two idexes of date
        if(year_ == year) //  checks if their equivalent 
        {
            arr[count] = posts_[i].getPostBody(); // sets the index of the current counter in array arr to the body of the post at given index i that matched years with given year in parameter 
            count++;
        }
    }
    if(count == 0) // checks if no years matched 
    {
        cout << "No posts stored for year " << year << endl; 
        return;
    }

    if(count >= 1) // checks if at least one post matched the year parameter 
    {
        cout << "Here is a list of posts for year " << year << endl; 
        for(int i = 0; i < count; i++) // iterates through the amount of post counted with correct year and prints them out 
        {
            cout << arr[i] << endl;
        }
    }
}
int Buffchat::readLikes(string file_name)
{
     if(num_users_ == users_size_) //makes sure that the users array is not already full and returns -2 if it is 
    {
        return -2;
    }
    ifstream file_input; 
    file_input.open(file_name); // opens file 
    if(file_input.fail() && num_users_ == users_size_) // makes sure the file does not fail to open and the users array is not already full and return -2 if it is
    {
        return -2; 
    }
    if (file_input.fail()) //makes sure the file does not fail to open and returns -1 if it does fail to open 
    {
        return -1; 
    }
    else
    {
        string line = ""; // parameter for split 
        string arr[users_size_+1]; // creates an array to pass into split 
        int likes[50]; // initializes likes array to the max number of posts stored 
        while(!file_input.eof() && num_users_ < users_size_) // loops while there is still more data to be read in the file and the number of users stored does not exceed the size of the array 
        {
            getline(file_input, line); // gets line 
            int x = split(line,',',arr,51); // calls helper function split that interated through a string and splits into an array based on a delimeter and returns the numbers of splits
            if(line != "" && (x <= 51 && x > 0))
            {
                for(int i = 0; i < x-1; i++) // interates through the maximum amount of posts 
                {
                    likes[i] = stoi(arr[i+1]);
                    //cout << "printing likes" << endl;
                    //cout << arr[i+1] << endl;
                    // users_[num_users_].setLikesAt(i,stoi(arr[i+1]));
                    //cout << users_[num_users_].getLikesAt(i) << endl;
                    //cout << "printing likes" << endl;
                }
                string name; 
                name = arr[0];
                User user = User(name, likes, x-1);
                users_[num_users_] = user;
                // users_[num_users_].setUsername(arr[0]); 
                // users_[num_users_].setNumPosts(x-1);
            }
            num_users_++;  // increments number of users stored 
        }
        file_input.close(); // closes file 
        return num_users_; 
    }
}
int Buffchat::getLikes(string post_author, string username)
{
    if(num_posts_ <= 0 || num_users_ <= 0) // checks to make sure there are at least 1 post and at least 1 user in each array 
    {
        return -2;
    }
    int post_index = -1; // used to find index of post
    int user_index = -1; // used to find index of post
    bool user = false; // used to check if the user exist or not
    bool post = false; // used to check if the post exist or not 
    for(int i = 0; i < num_posts_; i++) // find the post index and sets post to true if it exist 
    {
        if(posts_[i].getPostAuthor() == post_author)
        {
            post_index = i; 
            post = true;
            break;
        }
    }
    for(int i = 0; i < num_users_; i++) //finds the user index and sets user to true if it exist 
    {
        if(users_[i].getUsername() == username)
        {
            user_index = i; 
            user = true;
            break;
        }
    }
    if(post == false || user == false) // checks to see if post or user dont exist and return -3 if either or both dont exist 
    {
        return -3;
    }

    return users_[user_index].getLikesAt(post_index);
}
void Buffchat::findTagUser(string user_tag)
{
    int num_users_found = 0; // number of users found will be incremented throughout the program or checked to be zero at the end  
    User user_temp[num_users_]; // declared a user temp array to the size of the number of users stored in users
    int tag_length = user_tag.length(); // creates a integer varaible that is equal to the length of the tag to be used in substring interation 
    for(int i = 0; i < num_users_; i++) // intereates through the total number of users stored 
    {
        int length = users_[i].getUsername().length(); // creates a integer variable that is equal to length of the username at a given index i 
        for(int x = 0; x < length; x++) // interated through the length of the username 
        {
            if(users_[i].getUsername().substr(x,tag_length) == user_tag) // gets if the substring x to the length of the tag is equal to the username tag 
            {
                user_temp[num_users_found] = users_[i]; // if it is equal to then it sets that username to the index of the number of users found in the user_temp array, to be used to print out list of usernames that contain the username tag 
                num_users_found++; // increments number of users found 
            }
        }
    }
    if(num_users_ <= 0) // checks if there are not users in the array 
    {
        cout << "No users are stored in the database" << endl; 
        return; 
    }

    if(num_users_found == 0) // checks if no users that contain the tag were in the array 
    {
        cout << "No matching user found" << endl; 
        return;
    }
    if(num_users_found >= 1) // checks if at least one username in the array contained the tag 
    {
        cout << "Here are all the usernames that contain " << user_tag << endl; // prints on a loop all the usernames that contian the tag in the temp array 
        for(int i = 0; i < num_users_found; i++)
        {
            cout << user_temp[i].getUsername() << endl;
        }
    }
}
bool Buffchat::addPost(string post_body, string post_author, string date)
{
    if(num_posts_ < posts_size_) // checks to make sure that the post array is not already full 
    {
        posts_[num_posts_].setPostBody(post_body); 
        posts_[num_posts_].setPostAuthor(post_author); 
        posts_[num_posts_].setPostDate(post_author); 
        posts_[num_posts_].setPostLikes(-1);
        for(int i = 0; i < 50; i++) // loop to set all the likes in the likes array to -1 
        {
            users_[i].setLikesAt(num_posts_,-1);
        }
        num_posts_++; // increments the number of likes stored
        return true; // returns true that it was able to add 
    }
    return false;
}
void Buffchat::printPopularPosts(int count, string year)
{
    int num = 0;
    int index = 0;
    Post temp_array[50]; // creates a temp array 
    int year_count = 0;
    if(num_posts_ <= 0) // checks to see if no post are stored in the posts array 
    {
        cout << "No posts are stored" << endl;
        return;
    }
    

    for(int i = 0; i < num_posts_; i++)
    {
        if(posts_[i].getPostDate().substr(6,7)==year)
        {
            temp_array[num] = posts_[i];
            num++; 
        }
    }
    if(num == 0) // checks if any posts matched the year in question
    {
        cout << "No posts stored for year " << year << endl;
        return;
    }

    if(count <= num)
    {
        int new_count = num;
        int min;
        cout << "Top " << count << " posts for year " << year << endl;
        while(new_count > count)
        {
            min = temp_array[0].getPostLikes();
            for(int i = 0; i < new_count; i++)
            {
                if(temp_array[i].getPostLikes() < min)
                {
                    min = temp_array[i].getPostLikes();
                    index = i;
                }
            }
            for(int i = index; i < new_count; i++)
            {
                temp_array[i] = temp_array[i+1];
            }
            new_count--;
        }
        for(int i = 0; i < count; i++)
        {
            cout << temp_array[i].getPostLikes() << " likes: " << temp_array[i].getPostBody() << endl;
        }
    }
    if(num < count) // checks to see if the number of posts with the year in question is less than the amount the user wanted to return 
    {
        cout << "There are fewer than " << count << " posts for year " << year << ". Top " << num << " posts for year " << year << endl;
        for(int i = 0; i < num; i++)
        {
            cout << temp_array[i].getPostLikes() << " likes: " << temp_array[i].getPostBody() << endl;
        }
    }
}
User Buffchat::findLeastActiveUser()
{
    int count = 0;
    int max_likes = 0;
    int user_index = 0;
    if(num_users_ == 0) // checks to see if the users array is empty returns a empty user if it is 
    {
        return User();
    }
    for(int i = 0; i < num_users_; i++) // loops through all the users 
    {
        for(int x = 0; x < users_[i].getNumPosts(); x++) // loops through all the likes 
        {
            if(users_[i].getLikesAt(x) == -1) // increments count for every like eqaul to -1
            {
                count++;
            }
            if(count > max_likes) // if count is greater than the number of posts in a the original leastactive than the least active user is reset
            {
                max_likes = count;
                user_index = i;
            }
        }
    }
    return users_[user_index]; 
}
int Buffchat::countUniqueLikes(string post_author)
{
    int post_index_array[50];
    int count_post = 0;
    if(num_posts_  == 0|| num_users_ == 0) // checks to make sure that both the users array and the post array are not equal to zero 
    {
        return -2;
    }
    for(int i = 0; i < num_posts_; i++) // find the post index and sets post to true if it exist 
    {
        if(posts_[i].getPostAuthor() == post_author)
        {
            post_index_array[count_post] = i; 
            cout << i << endl;
            count_post++;
        }
    }
    int count = 0;
    int no_view = 0;
    int zero_likes = 0;
    cout << count_post << endl;
    cout << num_users_ << endl;
    for(int i = 0; i < count_post; i++) // loops through all the users 
    {
        for(int x = 0; x < num_users_; x++)
        {
            
            if(users_[x].getLikesAt(post_index_array[i]) > 0) // checks if the like is greater than zero meaning its a true like
            {
                count++;
            }
            else if(users_[x].getLikesAt(post_index_array[i]) == -1)// checks to see if it has not been viewed by post_author
            {
                no_view = 1;
            }
            else if(users_[x].getLikesAt(post_index_array[i]) == 0) //checks to see if the likes are equal to 0
            {
                zero_likes = 1;
            }
        }
    }
    if(count == 0 && no_view == 0)
    {
        return 0;
    }
    else if(zero_likes == 0 && count == 0)
    {
       return -1;
    }
    return count;
}


void Buffchat::printLikes(int j)
{
    for(int i = 0; i < num_posts_; i++)
    {
        cout << users_[j].getLikesAt(i) << endl;
    }
}