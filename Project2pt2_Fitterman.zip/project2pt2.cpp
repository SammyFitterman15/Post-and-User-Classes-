//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 2 

#include <iostream>
using namespace std;
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert> 
#include "Buffchat.h"
#include "User.h"
#include "Post.h"


int main()
{
    string choice = "0"; 
    Buffchat buff = Buffchat();
    while(stoi(choice) != 10)
    {
        cout << "======Main Menu=====" << endl << "1. Read posts" << endl << "2. Print Posts By Year" << endl << "3. Read Likes" << endl << "4. Get Likes" << endl << "5. Find users with matching tag" << endl << "6. Add a new post" << endl << "7. Print popular posts for a year" << endl << "8. Find least active user" << endl << "9. Find unique likes for a post author" << endl << "10. Quit" << endl;
        getline(cin,choice);
        int new_choice = stoi(choice);
        switch(new_choice)
        {
            case 1:
                {
                string file_name = "";
                cout << "Enter a post file name:" << endl;
                getline(cin,file_name);
                int x = buff.readPosts("posts.txt");
                if(x == -1)
                {
                    cout << "File failed to open. No posts saved to the database." << endl;
                }
                else if(x == -2)
                {
                    cout << "Database is already full. No posts were added." << endl;
                }
                else if(x > 50)
                {
                    
                    cout << "Database is full. Some posts may have not been added." << endl;
                }
                else if(x >= 0 && x <= 50)
                {
                    
                    cout << "Total posts in the database: " << x << endl;
                }
                break;
                }   
            case 2:
                {
                string date = ""; 
                cout << "Enter the year(YY):" << endl;
                getline(cin,date);
                buff.printPostsByYear(date);
                break;
                }
            case 3:
                {
                string file_users = "";
                cout << "Enter user file name:" << endl;
                getline(cin,file_users);
                int y = buff.readLikes("users.txt");
                if(y == -1)
                {
                    cout << "File failed to open. No users saved to the database." << endl;
                }
                else if(y == -2)
                {
                    cout << "Database is already full. No users were added." << endl;
                }
                else if(y >= 50)
                {
                    
                    cout << "Database is full. Some users may have not been added." << endl;
                }
                else if(y >= 0 && y < 50)
                {
                    
                    cout << "Total users in the database: " << y << endl;
                }
                break;
                }
            case 4:
                {
                string post_author = ""; 
                cout << "Enter a post author:" << endl;
                getline(cin,post_author);
                string username = ""; 
                cout << "Enter a user name:" << endl;
                getline(cin,username);
                int z = buff.getLikes(post_author,username);
                if(z == 0)
                {
                    cout << username << " has not liked the post posted by " << post_author << endl;
                }
                else if(z == -1)
                {
                    cout << username << " has not viewed the post posted by " << post_author << endl;
                }
                else if(z == -2)
                {
                    cout << "Database is empty." << endl;
                }
                else if(z == -3)
                {
                    cout << username << " or " << post_author << " does not exist." << endl;
                }
                else
                {
                    cout << username << " liked the post posted by " << post_author << " " << z << " times" << endl;
                }
                break;
                }
            case 5:
                {
                string user_tag = "";
                cout << "Enter a tag:" << endl;
                getline(cin,user_tag);
                buff.findTagUser(user_tag);
                break;
                }
            case 6:
            {
                string body;
                string author;
                string date;
                cout << "Enter a post body: " << endl;
                getline(cin,body);
                cout << "Enter a post author: " << endl;
                getline(cin,author);
                cout << "Enter a date(mm/dd/yy):" << endl;
                getline(cin,date);
                bool b = buff.addPost(body, author, date);
                if(b)
                {
                    cout << author << "'s post added successfully" << endl;
                }
                else
                {
                    cout << "Database is already full. " << author << "'s post was not added" << endl;
                }
                break;
            }
            case 7:
            {
                int num;
                string year;
                cout << "Enter the number of posts: " << endl;
                cin >> num;
                cout << "Enter the year(yy):" << endl;
                cin >> year;
                buff.printPopularPosts(num,year);
                break;
            }
            case 8: 
            {
                User user = buff.findLeastActiveUser();
                if(user.getUsername() == "" && user.getNumPosts() == 0)
                {
                    cout << "There are no users stored" << endl;
                }
                else
                {
                    cout << user.getUsername() << " is the least active user" << endl;
                }
                break;
            }
            case 9: 
            {
                string post_author; 
                cout << "Enter a post author:" << endl;
                getline(cin, post_author);
                int result = buff.countUniqueLikes(post_author); 

                if(result >= 1)
                {
                    cout << "The posts posted by " << post_author << " have been liked by " << result << " unique users." << endl;
                }
                else if(result == 0)
                {
                    cout << "The posts posted by " << post_author << " have received 0 likes so far." << endl;
                }
                else if(result  == -1)
                {
                    cout << "The posts posted by " << post_author << " have not been viewed by anyone." << endl;
                }
                else if(result  == -2)
                {
                    cout << "Database is empty." << endl;
                }
                break;
            }
            case 10: 
            {
                cout << "Good bye!" << endl;
                break;
            }
            default:
            {
                cout << "Invalid input" << endl;
                break;
            }
           
        }
    }
    return 0;

}