//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 2 

#include <iostream>
using namespace std;
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert> 
#include "Buffchat.h"
#include "User.h"
#include "Post.h"




int main()
{
    Buffchat buff = Buffchat(); 
    assert(buff.getPostSize() == 50);
    assert(buff.getUserSize() == 50);
    assert(buff.getNumPosts() == 0);
    assert(buff.getNumUsers() == 0);
    assert(buff.readPosts("posts.txt") == 50); 
    assert(buff.readLikes("users.txt") == 50);
    buff.printPostsByYear("22");
    assert(buff.getLikes("susanfrances", "vengefulSauce") == 2); // both username and author exist, and value of likes is non zero
    assert(buff.getLikes("susanfrances", "susanfrances") == 0); // both username and author exist, and value of likes is zero
    assert(buff.getLikes("caseymac", "mila") == -3); // both the username and post author do not exist 
    buff.findTagUser("buff");
    assert(buff.addPost("This is my post", "Sammy","03/29/04") == false);
    buff.printPopularPosts(3,"22"); // gets error libc++abi: terminating with uncaught exception of type std::out_of_range: basic_string zsh: abort      ./a.out
    User u = buff.findLeastActiveUser();
    //assert(buff.countUniqueLikes("glenn56") == 91);

    return 0;
}