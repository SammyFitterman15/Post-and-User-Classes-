//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 1 question 4

#ifndef USER_H
#define USER_H
#include <iostream>
using namespace std;
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert> 


class User
{
    private: 
        string username_;
        int num_posts_;
        static const int size_ = 50; 
        int likes_[size_];
    public:  
        User();
        User(string username, int likes[], int num_posts); 
        string getUsername();
        void setUsername(string username);
        int getLikesAt(int post_id); 
        bool setLikesAt(int post_id, int num_likes);
        int getSize();
        void setNumPosts(int num_posts);
        int getNumPosts();
};


#endif
