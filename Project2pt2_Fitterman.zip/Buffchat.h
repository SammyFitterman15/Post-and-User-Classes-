//CSCI 1300 Fall 2022
//Author Sammy Fitterman
//Recitation: 106 - C.Park
//Project 2 part 2 question 0

#ifndef BUFFCHAT_H
#define BUFFCHAT_H
#include <iostream>
#include <cmath>
#include <cstring> 
#include <iomanip> 
#include <string>
#include <fstream>
#include <cassert> 
#include "Post.h"
#include "User.h"
using namespace std;

class Buffchat 
{
    private: 
        const static int posts_size_ = 50;
        const static int users_size_ = 50;
        Post posts_[50];
        User users_[50];
        int num_posts_;
        int num_users_;
    public: 
        Buffchat();
        int getPostSize();
        int getUserSize();
        int getNumPosts();
        int getNumUsers();
        int readPosts(string file_name);
        void printPostsByYear(string year);
        int readLikes(string file_name);
        int getLikes(string post_author, string username);
        void findTagUser(string user_tag);
        bool addPost(string post_body, string post_author, string date);
        void printPopularPosts(int count, string year);
        User findLeastActiveUser();
        int countUniqueLikes(string post_author);
        void printLikes(int j);
};


#endif





